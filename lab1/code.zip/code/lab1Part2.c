#include "lab1.h"

float S(float a, float b)
{
    
}