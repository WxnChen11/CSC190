#include "lab1.h"

float f(float x)
{
    
}