#include "lab2.h"


void readMatrix(char * filename, int * matrix)
{
}

void printMatrix(int n, int *A)
{
}

void sum(int *A, int *B, int *res, int n)
{
}

void sub(int *A, int *B, int *res, int n)
{
}

int determinant(int n, int *matrix)
{
}
